"""Explainable scam-message analysis: pattern rules + embedded-link checks."""
import re

from .url_analyzer import _combine, analyze_url, extract_urls, level_for

# (code, title, regex, weight, why-it-matters)
RULES = [
    ("otp", "Asks for OTP / PIN / CVV",
     r"\b(share|send|tell|give|enter|provide|forward)\b.{0,40}\b(otp|pin|cvv|password|passcode)\b|\b(otp|cvv|pin)\b.{0,25}\b(share|send|tell|give)\b",
     65, "No bank or app ever asks for your OTP, PIN or CVV. Sharing it hands over your money."),
    ("kyc", "KYC / account-block threat",
     r"\b(kyc|pan|aadhaar|aadhar)\b.{0,50}\b(expire|expired|update|verify|suspend|block|blocked|deactivat)|\b(account|card|sim|wallet)\b.{0,40}\b(blocked|suspended|deactivated|frozen|will be closed)",
     40, "Scammers invent an 'account problem' to make you panic and click."),
    ("urgent", "Pressure and urgency",
     r"\b(urgent|immediately|right now|within \d+ ?(hours?|hrs?|minutes?|mins?)|last chance|final notice|act now|expires? (today|soon)|today only|hurry)\b",
     22, "Urgency stops you from thinking. Genuine organisations give you time."),
    ("prize", "Prize, lottery or free gift",
     r"\b(congratulations?|you (have )?won|winner|lottery|lucky draw|jackpot|free gift|cashback of|claim your (prize|reward|gift))\b",
     40, "You cannot win a contest you never entered."),
    ("money", "Asks you to send / pay money",
     r"\b(send|transfer|pay|deposit)\b.{0,40}(rs\.?|inr|₹|\$|rupees|fee|charges|advance)|\b(processing|registration|clearance|customs) fee\b|\bgift ?cards?\b|\b(crypto|bitcoin|usdt)\b",
     35, "Upfront fees and gift-card or crypto payments are a hallmark of fraud."),
    ("job", "Too-good-to-be-true job offer",
     r"\b(work from home|part[- ]?time job|earn (rs\.?|₹)? ?\d[\d,]*.{0,20}(daily|per day|weekly)|like (and )?(subscribe|youtube)|task[- ]based)\b",
     35, "Task/‘like and earn’ jobs are a leading fraud type in India."),
    ("authority", "Claims to be police, courier or govt.",
     r"\b(cbi|customs|narcotics|police|cyber ?cell|trai|rbi|income ?tax|enforcement directorate|fedex|dhl)\b.{0,80}\b(arrest|parcel|package|case|illegal|warrant|seized|drugs)\b|\bdigital arrest\b",
     50, "Real agencies never arrest people over video call or demand payment to 'clear' a case."),
    ("remote", "Asks to install a remote-access app",
     r"\b(anydesk|teamviewer|quicksupport|rustdesk|screen ?share)\b",
     50, "Remote-access apps give a stranger full control of your phone."),
    ("upi", "UPI collect / refund trick",
     r"\b(scan (this )?qr|collect request|approve (the )?request|enter (your )?upi pin)\b.{0,50}\b(receive|refund|get|credit)\b|\bto receive (money|payment)\b.{0,40}\b(pin|scan)\b",
     45, "You never need to enter a PIN or scan a code to RECEIVE money."),
    ("link_action", "Tells you to click a link",
     r"\b(click|tap|open|visit|login|log in)\b.{0,30}\b(link|here|below|now)\b",
     14, "Unexpected links are the main way phishing works."),
    ("secrecy", "Asks for secrecy",
     r"\b(do not|don't|dont) (tell|inform|discuss)\b.{0,30}\b(anyone|family|bank|police)\b|\bkeep (this )?(confidential|secret)\b",
     30, "Isolation is a control tactic. Talk to someone you trust."),
    ("unknown_sender", "Generic greeting",
     r"^\s*(dear (customer|user|sir|madam|account holder|valued))\b",
     10, "Real banks address you by name."),
]

ADVICE = {
    "dangerous": [
        "Do not click links, call back numbers in the message, or share any code.",
        "Report it: call 1930 (National Cyber Crime Helpline) or visit cybercrime.gov.in.",
        "If you already paid or shared details, call your bank's official number immediately and ask to block the card/UPI.",
    ],
    "suspicious": [
        "Do not act on it yet. Contact the organisation using the number printed on your card or their official app.",
        "Ask someone you trust before clicking anything.",
    ],
    "safe": [
        "No strong scam signals found - but no tool is perfect. Stay alert to unexpected requests for money or codes.",
    ],
}


def analyze_text(text):
    text = (text or "").strip()
    findings = []
    for code, title, pattern, weight, why in RULES:
        m = re.search(pattern, text, re.I | re.S)
        if m:
            snippet = re.sub(r"\s+", " ", m.group(0)).strip()[:80]
            findings.append({"code": code, "title": title, "detail": why,
                             "weight": weight, "evidence": snippet})

    links = []
    for u in extract_urls(text)[:10]:
        res = analyze_url(u)
        links.append(res)
        if res["level"] != "safe":
            findings.append({
                "code": "risky_link", "title": f"Risky link: {res['host'] or u}",
                "detail": "; ".join(f["title"] for f in res["findings"][:3]),
                "weight": min(res["score"], 70), "evidence": u[:80]})

    if len(findings) >= 3:   # several independent red flags together is more telling
        findings.append({"code": "combo", "title": "Multiple red flags together",
                         "detail": "Any one flag can be innocent; this many together rarely is.",
                         "weight": 15, "evidence": ""})

    score = _combine([f["weight"] for f in findings])
    lvl = level_for(score)
    return {"score": score, "level": lvl, "findings": sorted(findings, key=lambda f: -f["weight"]),
            "links": links, "advice": ADVICE[lvl], "length": len(text)}
