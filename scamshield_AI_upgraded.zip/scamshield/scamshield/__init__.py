"""ScamShield - explainable scam, phishing and link-safety analysis."""
__version__ = "1.0.0"
