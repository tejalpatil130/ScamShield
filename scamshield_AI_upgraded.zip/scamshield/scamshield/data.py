"""Static knowledge used by the analyzers (brands, TLDs, shorteners, passwords)."""

# brand keyword -> official registered domains
BRANDS = {
    "sbi": ["sbi.co.in", "onlinesbi.sbi", "sbicard.com"],
    "hdfc": ["hdfcbank.com", "hdfc.com", "hdfclife.com"],
    "icici": ["icicibank.com", "icicilombard.com", "iciciprulife.com"],
    "axis": ["axisbank.com"],
    "paytm": ["paytm.com"],
    "phonepe": ["phonepe.com"],
    "amazon": ["amazon.in", "amazon.com"],
    "flipkart": ["flipkart.com"],
    "google": ["google.com", "google.co.in"],
    "microsoft": ["microsoft.com", "live.com", "office.com"],
    "paypal": ["paypal.com"],
    "netflix": ["netflix.com"],
    "instagram": ["instagram.com"],
    "facebook": ["facebook.com", "fb.com"],
    "whatsapp": ["whatsapp.com", "whatsapp.net"],
    "apple": ["apple.com", "icloud.com"],
    "irctc": ["irctc.co.in"],
    "uidai": ["uidai.gov.in"],
    "incometax": ["incometax.gov.in"],
    "npci": ["npci.org.in"],
}

URL_SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy",
    "shorturl.at", "ow.ly", "buff.ly", "tiny.cc", "rebrand.ly",
}

SUSPICIOUS_TLDS = {
    "xyz", "top", "click", "link", "work", "support", "live", "loan", "win",
    "gq", "tk", "ml", "cf", "ga", "icu", "buzz", "monster", "rest", "cyou",
}

# Two-level public suffixes we care about (keeps us dependency-free).
TWO_LEVEL_SUFFIXES = {
    "co.in", "gov.in", "org.in", "net.in", "ac.in", "nic.in", "co.uk", "org.uk",
    "com.au", "co.jp", "com.br",
}

PHISH_URL_WORDS = {
    "login", "signin", "verify", "update", "secure", "account", "banking",
    "kyc", "wallet", "confirm", "suspend", "unlock", "reward", "claim", "bonus",
    "refund", "password", "otp",
}
