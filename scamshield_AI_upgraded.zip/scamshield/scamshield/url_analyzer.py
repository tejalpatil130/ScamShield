"""Explainable URL risk analysis using only the standard library."""
import ipaddress
import math
import re
from urllib.parse import urlparse

from .data import (BRANDS, PHISH_URL_WORDS, SUSPICIOUS_TLDS, TWO_LEVEL_SUFFIXES,
                   URL_SHORTENERS)

URL_RE = re.compile(r"(?:https?://|www\.)[^\s<>\"']+|(?<![@\w.-])[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:com|in|net|org|xyz|top|click|link|support|live|work|win|icu|buzz|tk|ml|ga|cf|gq|sbi)(?:/[^\s<>\"']*)?", re.I)


def extract_urls(text):
    """Return de-duplicated URL-like strings found in free text."""
    seen, out = set(), []
    for m in URL_RE.finditer(text or ""):
        u = m.group(0).rstrip(".,;:!?)")
        if "@" in u and "/" not in u:   # looks like an email address, skip
            continue
        if u.lower() not in seen:
            seen.add(u.lower())
            out.append(u)
    return out


def levenshtein(a, b):
    if a == b:
        return 0
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def registered_domain(host):
    parts = host.split(".")
    if len(parts) >= 3 and ".".join(parts[-2:]) in TWO_LEVEL_SUFFIXES:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def _entropy(s):
    if not s:
        return 0.0
    freq = {c: s.count(c) for c in set(s)}
    return -sum(v / len(s) * math.log2(v / len(s)) for v in freq.values())


def _is_ip(host):
    try:
        ipaddress.ip_address(host.strip("[]"))
        return True
    except ValueError:
        return False


def analyze_url(raw):
    """Return {url, host, score, level, findings[]} - score is 0..100."""
    raw = (raw or "").strip()
    findings = []

    def add(code, title, detail, weight):
        findings.append({"code": code, "title": title, "detail": detail, "weight": weight})

    if not raw:
        return {"url": raw, "host": "", "score": 0, "level": "safe", "findings": []}

    candidate = raw if re.match(r"^[a-z][a-z0-9+.-]*://", raw, re.I) else "http://" + raw
    try:
        p = urlparse(candidate)
        host = (p.hostname or "").lower()
    except ValueError:
        return {"url": raw, "host": "", "score": 60, "level": "suspicious",
                "findings": [{"code": "malformed", "title": "Malformed link",
                              "detail": "This link cannot be parsed properly.", "weight": 60}]}

    if not host:
        add("nohost", "No valid website name", "The link has no readable domain.", 60)
    else:
        reg = registered_domain(host)
        label = reg.split(".")[0]
        tld = host.rsplit(".", 1)[-1]

        if not raw.lower().startswith("https://") and not re.match(r"^[a-z]+://", raw, re.I):
            add("nohttps", "No secure connection stated",
                "The link does not clearly use HTTPS.", 8)
        elif p.scheme == "http":
            add("http", "Not encrypted (HTTP)", "Data typed here can be read by others. Real banks use HTTPS.", 15)

        if _is_ip(host):
            add("ip", "Address is a raw IP number", "Legitimate services use names, not numbers.", 40)
        if "@" in (p.netloc or ""):
            add("at", "Hidden '@' trick", "Text before '@' is ignored by the browser, so the real site is different from what it looks like.", 40)
        if host.startswith("xn--") or ".xn--" in host:
            add("punycode", "Look-alike characters (punycode)", "The domain may use foreign letters that imitate real ones.", 35)
        if host in URL_SHORTENERS or reg in URL_SHORTENERS:
            add("shortener", "Shortened link", "You cannot see where it really leads. Preview it before opening.", 25)
        if tld in SUSPICIOUS_TLDS:
            add("tld", f"Unusual ending '.{tld}'", "This ending is cheap and heavily used in scams.", 20)
        if host.count(".") >= 4:
            add("subdomains", "Too many sub-domains", "Attackers stack sub-domains to hide the real domain.", 18)
        if len(raw) > 90:
            add("long", "Very long link", "Long links are often used to hide the real destination.", 10)
        if label.count("-") >= 2 or (label.count("-") >= 1 and any(w in label for w in PHISH_URL_WORDS)):
            add("hyphens", "Hyphenated 'official-looking' name", "Names like 'bank-secure-login' are typical of fake sites.", 22)
        if sum(c.isdigit() for c in label) >= 3 and not label.isdigit():
            add("digits", "Many digits in the domain", "Random digits are common in throw-away scam domains.", 10)
        if len(label) >= 12 and _entropy(label) > 3.5:
            add("entropy", "Random-looking domain", "The name looks machine-generated.", 15)

        path_words = [w for w in PHISH_URL_WORDS if w in (host + p.path).lower()]
        if path_words:
            add("words", "Sensitive words in the link",
                "Contains: " + ", ".join(sorted(path_words)[:4]) + ".", min(8 + 4 * len(path_words), 20))

        # Brand impersonation
        brand_hit = None
        official = any(reg in doms for doms in BRANDS.values())
        if official:
            findings[:] = [f for f in findings if f["code"] not in ("words", "hyphens")]
        else:
            for brand in BRANDS:
                if len(brand) >= 5 and 0 < levenshtein(label, brand) <= 1:
                    brand_hit = (brand, "lookalike")
                    break
            if not brand_hit:
                for brand in BRANDS:
                    if (len(brand) >= 4 and brand in host) or brand in host.split(".") or brand in label.split("-"):
                        brand_hit = (brand, "contains")
                        break
        if brand_hit:
            b, kind = brand_hit
            if kind == "lookalike":
                add("lookalike", f"Spelled almost like '{b}'",
                    f"'{reg}' is one letter away from the real brand. Classic typo-squatting.", 55)
            else:
                add("impersonation", f"Pretends to be '{b}'",
                    f"'{reg}' is not an official {b} domain ({', '.join(BRANDS[b][:2])}).", 50)

    score = _combine([f["weight"] for f in findings])
    return {"url": raw, "host": host, "score": score, "level": level_for(score), "findings": findings}


def _combine(weights):
    """Noisy-OR: independent signals reinforce each other but never exceed 100."""
    p = 1.0
    for w in weights:
        p *= 1 - min(max(w, 0), 95) / 100
    return round((1 - p) * 100)


def level_for(score):
    return "dangerous" if score >= 60 else "suspicious" if score >= 30 else "safe"
