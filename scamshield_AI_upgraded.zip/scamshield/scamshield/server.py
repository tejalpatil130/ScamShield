
"""ScamShield web server with authentication, user/admin dashboards and AI tools."""
import json, mimetypes, os, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from . import __version__, ai_analyzer
from .text_analyzer import analyze_text
from .url_analyzer import analyze_url, level_for
from . import auth, smart_ai

WEB_DIR = Path(__file__).resolve().parent.parent / "web"
MAX_BODY=25000
RATE_LIMIT=100
_hits={}; _ai_hits={}

def _limited(ip):
    now=time.time(); h=[x for x in _hits.get(ip,[]) if now-x<60]; h.append(now); _hits[ip]=h
    return len(h)>RATE_LIMIT
def _ai_limited(ip):
    now=time.time(); h=[x for x in _ai_hits.get(ip,[]) if now-x<60]; h.append(now); _ai_hits[ip]=h
    return len(h)>15

class Handler(BaseHTTPRequestHandler):
    server_version="ScamShield/"+__version__
    def log_message(self,fmt,*args): pass
    def _send(self,code,body,ctype="application/json",extra=None):
        if isinstance(body,(dict,list)): body=json.dumps(body).encode()
        elif isinstance(body,str): body=body.encode()
        self.send_response(code); self.send_header("Content-Type",ctype)
        self.send_header("Content-Length",str(len(body)))
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Referrer-Policy","no-referrer")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Security-Policy","default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; frame-ancestors 'none'")
        if extra:
            for k,v in extra.items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(body)
    def _token(self):
        c=self.headers.get("Cookie","")
        for item in c.split(";"):
            if item.strip().startswith("ss_token="): return item.strip().split("=",1)[1]
        return None
    def _me(self): return auth.user_from_token(self._token())
    def _need(self,role=None):
        me=self._me()
        if not me: self._send(401,{"error":"Login required."}); return None
        if role and me["role"]!=role: self._send(403,{"error":"Admin access required."}); return None
        return me
    def _body(self):
        try:n=int(self.headers.get("Content-Length",0))
        except ValueError:n=0
        if n<=0 or n>MAX_BODY: raise ValueError("Body must be 1-25000 bytes.")
        try:return json.loads(self.rfile.read(n))
        except Exception: raise ValueError("Invalid JSON.")
    def do_GET(self):
        path=unquote(urlparse(self.path).path)
        if path=="/api/health":
            return self._send(200,{"status":"ok","version":__version__,"ai_enabled":ai_analyzer.enabled(),"local_ai":True})
        if path=="/api/me":
            me=self._me(); return self._send(200,{"authenticated":bool(me),"user":me})
        if path=="/api/dashboard":
            me=self._need()
            return me and self._send(200,auth.user_stats(me["id"]))
        if path=="/api/admin/stats":
            me=self._need("admin")
            return me and self._send(200,auth.admin_stats())
        if path=="/api/admin/users":
            me=self._need("admin")
            return me and self._send(200,{"users":auth.all_users()})
        rel="index.html" if path in ("","/") else path.lstrip("/")
        f=(WEB_DIR/rel).resolve()
        if WEB_DIR not in f.parents or not f.is_file(): return self._send(404,{"error":"not found"})
        ctype=mimetypes.guess_type(str(f))[0] or "application/octet-stream"
        self._send(200,f.read_bytes(),ctype+("; charset=utf-8" if ctype.startswith("text") or "javascript" in ctype else ""))
    def do_POST(self):
        if _limited(self.client_address[0]): return self._send(429,{"error":"Too many requests. Please wait."})
        path=urlparse(self.path).path
        try:data=self._body()
        except ValueError as e:return self._send(400,{"error":str(e)})
        try:
            if path=="/api/auth/register":
                uid=auth.create_user(str(data.get("name","")),str(data.get("email","")),str(data.get("password","")))
                return self._send(201,{"message":"Account created. You can now log in.","user_id":uid})
            if path=="/api/auth/login":
                token,me=auth.login(str(data.get("email","")),str(data.get("password","")))
                return self._send(200,{"user":me},extra={"Set-Cookie":f"ss_token={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=28800"})
            if path=="/api/auth/logout":
                auth.logout(self._token()); return self._send(200,{"message":"Logged out."},extra={"Set-Cookie":"ss_token=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax"})
            me=self._me()
            if path.startswith("/api/analyze/") and not me:
                return self._send(401,{"error":"Login required to use analysis."})
            if path=="/api/analyze/text":
                text=str(data.get("text",""))[:5000]; result=analyze_text(text)
                smart=smart_ai.classify(text,result["score"])
                result["smart_ai"]=smart
                auth.save_scan(me["id"],"message",text,result["score"],result["level"],smart["scam_type"])
                return self._send(200,result)
            if path=="/api/analyze/url":
                url=str(data.get("url",""))[:2000]; result=analyze_url(url)
                smart=smart_ai.classify(url,result["score"]); result["smart_ai"]=smart
                auth.save_scan(me["id"],"link",url,result["score"],result["level"],smart["scam_type"])
                return self._send(200,result)
            if path=="/api/analyze/ai":
                text=str(data.get("text",""))[:5000]; lang=data.get("lang","en")
                result=analyze_text(text); result["smart_ai"]=smart_ai.classify(text,result["score"])
                if not ai_analyzer.enabled():
                    result["ai_error"]="Cloud AI is not configured. Local AI ensemble result is shown."
                elif _ai_limited(self.client_address[0]):
                    result["ai_error"]="Cloud AI limit reached. Local AI result is shown."
                else:
                    try:
                        ai=ai_analyzer.ask_claude(text,result,lang)
                        result["rule_score"]=result["score"]; result["score"]=ai_analyzer.blend(result["score"],ai["risk_score"])
                        result["level"]=level_for(result["score"]); result["ai"]=ai
                    except ai_analyzer.AIError as e: result["ai_error"]=str(e)
                auth.save_scan(me["id"],"ai",text,result["score"],result["level"],result.get("smart_ai",{}).get("scam_type",""))
                return self._send(200,result)
            if path=="/api/ai/classify":
                text=str(data.get("text",""))[:5000]
                return self._send(200,smart_ai.classify(text))
            if path=="/api/ai/sentiment":
                return self._send(200,smart_ai.analyze_sentiment(str(data.get("text",""))[:5000]))
            if path=="/api/ai/explain":
                text=str(data.get("text",""))[:5000]; result=analyze_text(text)
                return self._send(200,smart_ai.risk_explanation(result))
            if path=="/api/ai/safe-reply":
                text=str(data.get("text",""))[:5000]; r=smart_ai.classify(text)
                return self._send(200,{"reply":r["safe_reply"],"scam_type":r["scam_type"]})
            if path=="/api/ai/tip":
                return self._send(200,{"tip":smart_ai.multilingual_tip(str(data.get("lang","en")))})
            if path=="/api/admin/users/toggle":
                admin=self._need("admin")
                if not admin:return
                auth.set_active(int(data.get("user_id")),bool(data.get("active")))
                return self._send(200,{"message":"Account status updated."})
            return self._send(404,{"error":"not found"})
        except ValueError as e:return self._send(400,{"error":str(e)})
        except Exception as e:return self._send(500,{"error":"Server error."})
def run(host="127.0.0.1",port=None):
    port=int(port or os.environ.get("PORT",8000))
    auth.init()
    srv=ThreadingHTTPServer((host,port),Handler)
    print(f"ScamShield running at http://{host}:{port} (Ctrl+C to stop)")
    try:srv.serve_forever()
    except KeyboardInterrupt: print("\nBye!")
