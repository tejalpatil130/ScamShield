
"""Local AI-style ensemble: explainable classification, scam-type detection, tone and safe reply."""
import re
from collections import Counter

SCAM_TYPES = {
 "KYC / phishing": [r"\bkyc\b",r"\bverify\b",r"\bupdate\b.{0,30}\baccount\b",r"\bblocked\b",r"\bsuspend"],
 "UPI / payment fraud": [r"\bupi\b",r"\bcollect request\b",r"\bupi pin\b",r"\bqr\b",r"\brefund\b",r"\btransfer\b"],
 "Digital arrest / authority impersonation": [r"digital arrest",r"\bcbi\b",r"\bpolice\b",r"\bcyber ?cell\b",r"\bnarcotics\b",r"\bwarrant\b"],
 "Job / task scam": [r"work from home",r"part[- ]time",r"earn.{0,20}\b\d+",r"like.{0,20}(youtube|video)",r"task[- ]based"],
 "Prize / lottery scam": [r"you (have )?won",r"lottery",r"jackpot",r"lucky draw",r"claim.{0,20}(prize|reward|gift)"],
 "Remote-access scam": [r"anydesk",r"teamviewer",r"quicksupport",r"screen ?share",r"remote access"],
 "Phishing / malicious link": [r"click",r"tap",r"login",r"sign ?in",r"http://",r"https://",r"verify link"],
 "Investment / crypto fraud": [r"guaranteed return",r"double your money",r"crypto",r"bitcoin",r"usdt",r"investment"],
}

URGENCY = [r"urgent",r"immediately",r"right now",r"within \d+",r"last chance",r"act now",r"hurry",r"today"]
EMOTION = {"fear":[r"arrest",r"police",r"blocked",r"illegal",r"case",r"drugs",r"seized"],
           "greed":[r"won",r"prize",r"bonus",r"cashback",r"earn",r"profit",r"reward"],
           "pressure":[r"urgent",r"immediately",r"now",r"final",r"expires",r"hurry"]}

def _hits(text, patterns):
    return [p for p in patterns if re.search(p, text, re.I|re.S)]

def classify(text, base=None):
    text = (text or "").strip()
    scores = Counter()
    evidence = {}
    for name, pats in SCAM_TYPES.items():
        h = _hits(text,pats)
        if h:
            scores[name] += len(h)*18
            evidence[name] = len(h)
    urgency = len(_hits(text,URGENCY))
    emotion = {k:len(_hits(text,v)) for k,v in EMOTION.items()}
    url_count = len(re.findall(r"https?://|www\.",text,re.I))
    if urgency: scores["Pressure / urgency"] += urgency*8
    if url_count: scores["Phishing / malicious link"] += 12
    top = scores.most_common(3)
    top_score = min(100, sum(v for _,v in top))
    if base is not None:
        top_score = round((top_score + int(base))/2)
    if top_score >= 60: verdict="dangerous"
    elif top_score >= 30: verdict="suspicious"
    else: verdict="safe"
    scam_type = top[0][0] if top else "No strong scam pattern"
    explanation = explain(verdict, scam_type, urgency, url_count, emotion)
    return {"risk_score":top_score,"verdict":verdict,"scam_type":scam_type,
            "confidence": min(99, 55 + len(top)*12 + urgency*4),
            "signals":{"urgency":urgency,"links":url_count,"emotion":emotion,"categories":dict(top)},
            "explanation":explanation,"safe_reply":safe_reply(verdict,scam_type)}

def explain(verdict, scam_type, urgency, links, emotion):
    if verdict=="dangerous":
        return f"The message strongly matches {scam_type.lower()} patterns. It also contains {urgency} urgency signal(s) and {links} link(s), so pause and verify through an official channel."
    if verdict=="suspicious":
        return f"The message has warning signs associated with {scam_type.lower()}. Do not share OTPs, PINs or money until the sender is independently verified."
    return "No strong scam pattern was detected by the local AI ensemble. This is not proof that the message is genuine; verify unexpected requests independently."

def safe_reply(verdict, scam_type):
    if verdict=="safe": return "No reply needed unless you know the sender."
    if "authority" in scam_type.lower() or "arrest" in scam_type.lower():
        return "I will verify this directly with the official department; I will not pay or share information."
    if "job" in scam_type.lower():
        return "Please send the official company website and written offer; I will verify independently."
    return "I do not share OTPs, PINs or payments through messages. I will verify through the official app or website."

def analyze_sentiment(text):
    t=(text or "").lower()
    fear=len(re.findall(r"\barrest|police|blocked|illegal|drugs|case|seized\b",t))
    urgency=len(re.findall(r"\burgent|immediately|now|hurry|final|expires\b",t))
    greed=len(re.findall(r"\bwon|prize|bonus|cashback|earn|reward|profit\b",t))
    return {"fear":fear,"urgency":urgency,"greed":greed,
            "dominant":max(("fear",fear),("urgency",urgency),("greed",greed),key=lambda x:x[1])[0] if max(fear,urgency,greed)>0 else "neutral"}

def risk_explanation(result):
    level=result.get("level") or result.get("verdict","safe")
    score=int(result.get("score",result.get("risk_score",0)))
    findings=result.get("findings",[])
    if not findings:
        return {"headline":"No strong rule signals found","points":["Still verify unexpected requests independently.","Never share OTP, PIN or CVV.","Use official apps and saved contacts for important actions."]}
    points=[f"{f['title']}: {f['detail']}" for f in findings[:5]]
    return {"headline":f"Risk score {score}/100 — {level.title()}","points":points}

def multilingual_tip(lang):
    tips={
      "en":"Stop. Verify the sender independently. Never share OTP, PIN or CVV.",
      "hi":"रुकें। Sender को official source से verify करें। OTP, PIN या CVV कभी share न करें।",
      "mr":"थांबा. Sender ला official source मधून verify करा. OTP, PIN किंवा CVV कधीही share करू नका.",
      "ta":"நிறுத்துங்கள். அதிகாரப்பூர்வ வழியில் சரிபார்க்கவும். OTP, PIN, CVV பகிர வேண்டாம்.",
      "te":"ఆగండి. అధికారిక మార్గంలో పంపినవారిని ధృవీకరించండి. OTP, PIN, CVV పంచుకోవద్దు."
    }
    return tips.get(lang,tips["en"])
