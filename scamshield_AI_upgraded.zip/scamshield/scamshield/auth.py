
"""ScamShield authentication, sessions and SQLite persistence."""
import base64, hashlib, hmac, os, secrets, sqlite3, time
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent / "db" / "scamshield.db"
PBKDF2_ROUNDS = 180_000
SESSIONS = {}

def _db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        created_at REAL NOT NULL,
        active INTEGER NOT NULL DEFAULT 1)""")
    con.execute("""CREATE TABLE IF NOT EXISTS scans(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        kind TEXT NOT NULL,
        input_preview TEXT,
        score INTEGER NOT NULL,
        level TEXT NOT NULL,
        scam_type TEXT,
        created_at REAL NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id))""")
    con.execute("""CREATE TABLE IF NOT EXISTS reports(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT,
        details TEXT,
        created_at REAL NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id))""")
    con.commit()
    return con

def _hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ROUNDS)
    return base64.b64encode(salt).decode() + "$" + base64.b64encode(digest).decode()

def _verify(password, stored):
    try:
        salt, digest = stored.split("$", 1)
        salt_b = base64.b64decode(salt)
        got = hashlib.pbkdf2_hmac("sha256", password.encode(), salt_b, PBKDF2_ROUNDS)
        return hmac.compare_digest(got, base64.b64decode(digest))
    except Exception:
        return False

def init():
    con = _db()
    row = con.execute("SELECT id FROM users WHERE role='admin' LIMIT 1").fetchone()
    if not row:
        con.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                    ("System Admin","admin@scamshield.local",_hash("Admin@123"),"admin",time.time()))
        con.commit()
    con.close()

def create_user(name, email, password, role="user"):
    if not name.strip() or len(password) < 8:
        raise ValueError("Name is required and password must be at least 8 characters.")
    email = email.strip().lower()
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        raise ValueError("Enter a valid email address.")
    con = _db()
    try:
        cur = con.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                          (name.strip(),email,_hash(password),role,time.time()))
        con.commit()
        return cur.lastrowid
    except sqlite3.IntegrityError:
        raise ValueError("An account with this email already exists.")
    finally:
        con.close()

def login(email, password):
    con = _db()
    row = con.execute("SELECT * FROM users WHERE email=? AND active=1", (email.strip().lower(),)).fetchone()
    con.close()
    if not row or not _verify(password, row["password_hash"]):
        raise ValueError("Invalid email or password.")
    token = secrets.token_urlsafe(32)
    SESSIONS[token] = {"id":row["id"],"name":row["name"],"email":row["email"],"role":row["role"],"created_at":time.time()}
    return token, SESSIONS[token]

def user_from_token(token):
    if not token or token not in SESSIONS:
        return None
    s = SESSIONS[token]
    if time.time() - s["created_at"] > 8*3600:
        SESSIONS.pop(token, None)
        return None
    return s

def logout(token):
    SESSIONS.pop(token, None)

def save_scan(user_id, kind, preview, score, level, scam_type=""):
    con = _db()
    con.execute("INSERT INTO scans(user_id,kind,input_preview,score,level,scam_type,created_at) VALUES(?,?,?,?,?,?,?)",
                (user_id,kind,preview[:180],int(score),level,scam_type[:80],time.time()))
    con.commit(); con.close()

def user_stats(user_id):
    con = _db()
    total = con.execute("SELECT COUNT(*) c FROM scans WHERE user_id=?", (user_id,)).fetchone()["c"]
    dangerous = con.execute("SELECT COUNT(*) c FROM scans WHERE user_id=? AND level='dangerous'", (user_id,)).fetchone()["c"]
    suspicious = con.execute("SELECT COUNT(*) c FROM scans WHERE user_id=? AND level='suspicious'", (user_id,)).fetchone()["c"]
    avg = con.execute("SELECT COALESCE(ROUND(AVG(score),1),0) a FROM scans WHERE user_id=?", (user_id,)).fetchone()["a"]
    recent = [dict(r) for r in con.execute(
        "SELECT id,kind,input_preview,score,level,scam_type,created_at FROM scans WHERE user_id=? ORDER BY id DESC LIMIT 10",
        (user_id,)).fetchall()]
    con.close()
    return {"total_scans":total,"dangerous":dangerous,"suspicious":suspicious,"average_score":avg,"recent":recent}

def admin_stats():
    con = _db()
    users = con.execute("SELECT COUNT(*) c FROM users WHERE role='user'").fetchone()["c"]
    admins = con.execute("SELECT COUNT(*) c FROM users WHERE role='admin'").fetchone()["c"]
    scans = con.execute("SELECT COUNT(*) c FROM scans").fetchone()["c"]
    dangerous = con.execute("SELECT COUNT(*) c FROM scans WHERE level='dangerous'").fetchone()["c"]
    suspicious = con.execute("SELECT COUNT(*) c FROM scans WHERE level='suspicious'").fetchone()["c"]
    avg = con.execute("SELECT COALESCE(ROUND(AVG(score),1),0) a FROM scans").fetchone()["a"]
    rows = [dict(r) for r in con.execute(
        "SELECT id,name,email,role,active,created_at FROM users ORDER BY id DESC LIMIT 30").fetchall()]
    types = [dict(r) for r in con.execute(
        "SELECT COALESCE(NULLIF(scam_type,''),'Rule-based') type, COUNT(*) count FROM scans GROUP BY type ORDER BY count DESC LIMIT 8").fetchall()]
    con.close()
    return {"users":users,"admins":admins,"scans":scans,"dangerous":dangerous,"suspicious":suspicious,"average_score":avg,"accounts":rows,"top_scam_types":types}

def all_users():
    con = _db()
    rows = [dict(r) for r in con.execute(
        "SELECT id,name,email,role,active,created_at FROM users ORDER BY id DESC").fetchall()]
    con.close(); return rows

def set_active(user_id, active):
    con = _db()
    con.execute("UPDATE users SET active=? WHERE id=? AND role='user'", (1 if active else 0,user_id))
    con.commit(); con.close()

init()
