# Architecture

```
Browser (web/)                        Python server (scamshield/)
 index.html + app.js  --JSON POST-->  server.py  (size limit, rate limit, headers)
  - Message tab  ------------------->   text_analyzer.analyze_text
  - Link tab     ------------------->        |-- 12 regex rules (weighted)
  - Password tab (client-side only)          |-- extract_urls -> url_analyzer.analyze_url
                                        url_analyzer  (host parsing, lookalike, TLD, IP, ...)
                                        data.py       (brands, shorteners, TLDs)
```

## Scoring
Each finding has a weight (0-95). Scores combine with **noisy-OR**: `score = 1 - Π(1 - wᵢ)`.
Independent red flags reinforce each other, one weak flag stays low, and the result never exceeds 100.
Levels: **safe** < 30, **suspicious** 30-59, **dangerous** ≥ 60.

## AI layer (optional)
`POST /api/analyze/ai` -> rules run first -> `redact()` -> Claude Messages API (stdlib `urllib`) -> `parse_reply()` validation -> `blend()`.
Any failure returns the rules-only result plus an `ai_error` note. Key comes from `ANTHROPIC_API_KEY`; never exposed to the browser.

## Why rules first (and AI on top)
- Every verdict is explainable to a non-technical user.
- No training data or GPU needed; runs anywhere; zero dependencies.
- Rules are easy for domain experts (bank fraud teams, police) to review and extend.

## Security decisions
- Input capped at 20 KB body / 5000 chars text / 2000 chars URL.
- Per-IP limit of 60 POSTs/min. Static file serving resolves paths and rejects anything outside `web/`.
- Logging disabled for request contents. No database, no cookies, no analytics.
- Strict CSP; the UI never uses `innerHTML`.

## Extending
Add a rule: append a tuple to `RULES` in `text_analyzer.py` and a test. Add a brand: one line in `data.py`.
