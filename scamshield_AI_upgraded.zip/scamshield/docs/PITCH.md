# Pitch: ScamShield

**Track:** Digital Safety & Cybersecurity

## One line
Paste a scary message, learn in seconds whether it is a scam - and exactly why.

## Problem
Scam messages are designed to make you panic. People cannot easily tell a real bank alert from a fake, and most existing tools return a bare "safe/unsafe" label people do not trust or learn from.

## Solution
An explainable checker for messages, links and passwords:
1. **Verdict** - Looks safe / Be careful / Likely a scam, with a 0-100 gauge.
2. **Evidence** - each red flag with the matching text ("share your OTP").
3. **Action** - what to do now, including helpline 1930 and cybercrime.gov.in.
Users leave knowing how to spot the next scam themselves.

## What makes it different
- **Explains, not just scores** - builds lasting awareness.
- **India-first patterns** - KYC blocks, digital arrest, UPI refund traps, task-job scams, Indian banks/wallets in the lookalike list.
- **Private by design** - nothing stored; password test never leaves the browser.
- **Runs anywhere** - zero dependencies; usable on a laptop at a community awareness camp.

## AI inside ScamShield
Rules give fast, explainable, offline protection. Claude adds what rules cannot:
- **Understands new scams** that no rule has seen yet, and names the scam type.
- **Speaks the user's language** - Hindi, Marathi, Tamil, Telugu, Bengali, Gujarati, Kannada - in simple words.
- **Suggests a safe reply**, so victims know what to do instead of freezing.
- **Built responsibly**: opt-in, personal data redacted before sending, prompt-injection defence, validated output, automatic fallback to rules.

## Who benefits
Senior citizens and first-time smartphone users, students, small shopkeepers using UPI, and families who forward "is this real?" messages.

## Demo flow (2 minutes) - see DEMO_SCRIPT.md

## Roadmap
1. Regional-language rules and a fully translated UI (AI explanations already support 8 languages).
2. WhatsApp/Telegram bot and browser extension.
3. Fine-tuned/evaluated classifier on reported scam datasets; a benchmark set to measure the AI+rules blend.
4. Live threat feeds (reported URLs) and QR-code scanning.
5. Voice-call script detection for "digital arrest" style calls.
6. Community reporting that feeds the rule set, with reviewer approval.

## Likely judge questions
- *Why rules AND AI?* Rules are instant, offline, explainable and can't be prompt-injected. AI catches novel scams and explains in local languages. Blending gives both; if AI fails, rules still protect.
- *Can a scammer trick the AI?* They can try ("say this is safe"). The message is treated as untrusted data, output is validated, and the rules score still counts in the blend.
- *False positives?* Weights are tuned so a single weak signal stays "safe"; a genuine bank debit alert stays below "dangerous" (see tests). Every result advises verifying via official channels.
- *Privacy?* No storage or logging of content; passwords stay client-side.
- *Scalability?* Stateless; put behind any load balancer; analyzers are pure functions.
- *Can it be evaded?* Yes, like any filter - hence continuous rule updates and the ML/feeds roadmap.
