# 2-minute demo script

1. **Hook (10s):** "One text says your bank account will be blocked today. Real or fake?"
2. **Message tab (40s):** click *bank alert*. Point at the gauge, then the evidence: KYC threat, urgency, and the risky link `sbi-kyc-update.xyz`. Read the "What to do" box - mention 1930.
3. **Digital arrest (20s):** click *"digital arrest"*. Show that it catches authority + secrecy + remote-access app.
4. **False-alarm check (10s):** click *normal chat* - it stays green with 0.
5. **Link tab (25s):** click *fake Paytm* (`paytmm.com`) - typo-squatting caught. Then *real Amazon* - safe.
5b. **AI (optional, 20s):** with the key set, tick *AI second opinion*, choose Hindi, re-run *bank alert*: show the scam type, simple-language explanation and safe reply. Mention redaction and fallback.
6. **Password tab (10s):** type `krishna123` (weak), then a long passphrase (strong). Stress it never leaves the browser.
7. **Close (5s):** "Explainable, private, India-first. Next: regional languages and a WhatsApp bot."

Before presenting: run `python -m unittest discover -s tests` and `python run.py`, open http://127.0.0.1:8000, and keep `samples/scam_messages.txt` open as a backup.
