
# ScamShield AI — Upgraded Cyber Safety Platform

ScamShield AI is an educational cybersecurity project for detecting scam messages and suspicious URLs.

## New modules
- **User module:** registration, secure login/logout, personal dashboard, scan history, AI tools.
- **Admin module:** admin login, platform statistics, detected scam categories, account enable/disable.
- **AI tools:** local scam-type classifier, confidence score, emotional-pressure analysis, explanation generator, safe-reply generator, multilingual safety tips.
- **Core detection:** explainable scam-message rules, URL phishing heuristics, password-strength checker from the original project.
- **Optional cloud AI:** the original Claude integration remains available through `ANTHROPIC_API_KEY`; local AI works without an API key.

## Demo credentials
Admin: `admin@scamshield.local`  
Password: `Admin@123`

Change this demo password before real deployment.

## Run
Requires Python 3.9+.

```bash
cd scamshield
python run.py
```

Open `http://127.0.0.1:8000`.

No third-party Python packages are required for the application itself.

## Project architecture

```text
Frontend (HTML/CSS/JS)
        |
        v
HTTP API / Authentication
        |
  +-----+----------------+
  |                      |
SQLite persistence    Analysis engines
  |                  /     |       \
Users/scans       Rules    URL      Local AI
  |                             
Admin/User dashboards
```

## Security notes
- Passwords use PBKDF2-HMAC-SHA256 with per-user salts.
- Session token is held in an HttpOnly cookie.
- Analysis data is stored as a short preview for dashboard history.
- Never use the demo credentials in production.
- This is a cybersecurity awareness tool, not a guarantee of fraud detection.

## API highlights
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/me`
- `GET /api/dashboard`
- `GET /api/admin/stats`
- `POST /api/analyze/text`
- `POST /api/analyze/url`
- `POST /api/ai/classify`
- `POST /api/ai/sentiment`
- `POST /api/ai/explain`
- `POST /api/ai/safe-reply`
- `POST /api/ai/tip`

## Suggested future work
Real-time threat-intelligence feeds, OCR for screenshots, transformer-based classification, email/browser extensions, stronger session storage, audit logs, 2FA and deployment behind HTTPS.
