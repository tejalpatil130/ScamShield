"""Start ScamShield:  python run.py   (optional: PORT=9000 HOST=0.0.0.0)"""
import os
from scamshield.server import run

if __name__ == "__main__":
    run(os.environ.get("HOST", "127.0.0.1"))
